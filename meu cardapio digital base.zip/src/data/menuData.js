
export const menuData = {
  caipirinhas: {
    title: 'Caipirinhas',
    items: [
      {
        id: 'caipirinha-tradicional',
        name: 'Caipirinha Tradicional',
        description: 'Pinga Velho Barreiro, limão, enfeite Super Drinks',
        sizes: [
          { size: '500ML', price: 30.00 },
          { size: '700ML', price: 35.00 },
          { size: '1L', price: 50.00 }
        ]
      },
      {
        id: 'brasileirinha',
        name: 'Brasileirinha',
        description: 'Pinga Velho Barreiro, limão, maracujá, enfeite Super Drinks',
        sizes: [
          { size: '500ML', price: 35.00 },
          { size: '700ML', price: 40.00 },
          { size: '1L', price: 55.00 }
        ]
      },
      {
        id: 'caipi-vodka',
        name: 'Caipi Vodka',
        description: 'Vodka Smirnoff N-01, escolha a fruta, enfeite Super Drinks',
        sizes: [
          { size: '500ML', price: 40.00 },
          { size: '700ML', price: 45.00 },
          { size: '1L', price: 60.00 }
        ]
      },
      {
        id: 'caipi-saque',
        name: 'Caipi Saquê',
        description: 'Saquê, escolha a fruta, enfeite Super Drinks',
        sizes: [
          { size: '500ML', price: 35.00 },
          { size: '700ML', price: 40.00 },
          { size: '1L', price: 55.00 }
        ]
      },
      {
        id: 'caipirinha-promocional',
        name: 'Caipirinha Promocional',
        description: 'Vodka Leonoff ou Pinga 51, escolha a fruta, enfeite Super Drinks',
        sizes: [
          { size: '500ML', price: 30.00 },
          { size: '700ML', price: 35.00 },
          { size: '1L', price: 45.00 }
        ]
      },
      {
        id: 'caipi-gin',
        name: 'Caipi Gin',
        description: 'Velho Barreiro, pinga, limão, abacaxi, enfeite Super Drinks',
        sizes: [
          { size: '500ML', price: 40.00 },
          { size: '700ML', price: 45.00 },
          { size: '1L', price: 60.00 }
        ]
      }
    ]
  },
  batidas: {
    title: 'Batidas',
    items: [
      {
        id: 'batida-danoninho',
        name: 'Batida Danoninho Adulterado',
        description: 'Velho Barreiro, fruta, leite condensado, enfeite Super Drinks',
        sizes: [
          { size: '500ML', price: 35.00 },
          { size: '700ML', price: 40.00 },
          { size: '1L', price: 55.00 }
        ]
      },
      {
        id: 'batida-gole-mal-caminho',
        name: 'Batida Gole de Mal Caminho',
        description: 'Vodka Smirnoff, fruta, leite condensado, enfeite Super Drinks',
        sizes: [
          { size: '500ML', price: 40.00 },
          { size: '700ML', price: 45.00 },
          { size: '1L', price: 60.00 }
        ]
      },
      {
        id: 'batida-ginzinho-misterioso',
        name: 'Batida Ginzinho Misterioso',
        description: 'Vodka Smirnoff, fruta, leite condensado, enfeite Super Drinks',
        sizes: [
          { size: '500ML', price: 40.00 },
          { size: '700ML', price: 45.00 },
          { size: '1L', price: 60.00 }
        ]
      }
    ]
  },
  sucos: {
    title: 'Sucos Naturais',
    items: [
      {
        id: 'super-sucos',
        name: 'Super Sucos',
        description: 'Limão, maracujá, morango, abacaxi - todos acompanham leite condensado',
        sizes: [
          { size: '500ML', price: 20.00 },
          { size: '700ML', price: 25.00 },
          { size: '1L', price: 35.00 }
        ]
      }
    ]
  },
  coqueteis: {
    title: 'Coquetéis',
    items: [
      {
        id: 'espanhola',
        name: 'Espanhola',
        description: 'Vinho tinto, abacaxi, leite condensado, enfeite Super Drinks',
        sizes: [
          { size: '500ML', price: 30.00 },
          { size: '700ML', price: 35.00 },
          { size: '1L', price: 50.00 }
        ]
      },
      {
        id: 'jorge-amado',
        name: 'Jorge Amado',
        description: 'Pinga Gabriela, limão, maracujá, enfeite Super Drinks',
        sizes: [
          { size: '500ML', price: 35.00 },
          { size: '700ML', price: 40.00 },
          { size: '1L', price: 55.00 }
        ]
      },
      {
        id: 'gin-tropical',
        name: 'Gin Tropical',
        description: 'Gin doce, morango, maracujá, enfeite Super Drinks',
        sizes: [
          { size: '500ML', price: 40.00 },
          { size: '700ML', price: 45.00 },
          { size: '1L', price: 60.00 }
        ]
      }
    ]
  },
  whisky: {
    title: 'Copão Whisky',
    items: [
      {
        id: 'old-star-gin',
        name: 'Old Star/Gin',
        description: 'Gelo de sabor, Bally',
        sizes: [
          { size: '500ML', price: 25.00 },
          { size: '700ML', price: 30.00 },
          { size: '1L', price: 40.00 }
        ]
      },
      {
        id: 'white-house',
        name: 'White House',
        description: 'Gelo de sabor, Bally',
        sizes: [
          { size: '500ML', price: 30.00 },
          { size: '700ML', price: 35.00 },
          { size: '1L', price: 45.00 }
        ]
      },
      {
        id: 'red-label',
        name: 'Red Label',
        description: 'Gelo de sabor, Bally',
        sizes: [
          { size: '500ML', price: 35.00 },
          { size: '700ML', price: 40.00 },
          { size: '1L', price: 50.00 }
        ]
      },
      {
        id: 'jack-daniels',
        name: 'Jack Daniel\'s',
        description: 'Gelo de sabor, Bally',
        sizes: [
          { size: '500ML', price: 40.00 },
          { size: '700ML', price: 45.00 },
          { size: '1L', price: 55.00 }
        ]
      }
    ]
  },
  doses: {
    title: 'Doses',
    items: [
      {
        id: 'pinga-velho-barreiro',
        name: 'Pinga Velho Barreiro',
        description: '51',
        sizes: [
          { size: '50ML', price: 5.00 }
        ]
      },
      {
        id: 'vodka',
        name: 'Vodka',
        description: '',
        sizes: [
          { size: '50ML', price: 8.00 }
        ]
      },
      {
        id: 'gin',
        name: 'Gin',
        description: '',
        sizes: [
          { size: '50ML', price: 10.00 }
        ]
      },
      {
        id: 'gabriela',
        name: 'Gabriela',
        description: '',
        sizes: [
          { size: '50ML', price: 12.00 }
        ]
      },
      {
        id: 'whisky',
        name: 'Whisky',
        description: '',
        sizes: [
          { size: '50ML', price: 15.00 }
        ]
      },
      {
        id: 'gelo-sabor',
        name: 'Gelo Sabor',
        description: '',
        sizes: [
          { size: 'UNID', price: 10.00 }
        ]
      }
    ]
  }
};

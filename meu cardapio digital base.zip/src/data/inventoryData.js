
export const initialInventory = [
  { id: 'pinga', name: 'Pinga Velho Barreiro', stock: 100, unit: 'doses', lowStock: 10 },
  { id: 'vodka', name: 'Vodka Smirnoff', stock: 80, unit: 'doses', lowStock: 10 },
  { id: 'saque', name: 'Saquê', stock: 50, unit: 'doses', lowStock: 5 },
  { id: 'gin', name: 'Gin', stock: 60, unit: 'doses', lowStock: 10 },
  { id: 'limao', name: 'Limão', stock: 200, unit: 'unid', lowStock: 20 },
  { id: 'maracuja', name: 'Maracujá', stock: 100, unit: 'unid', lowStock: 15 },
  { id: 'morango', name: 'Morango', stock: 150, unit: 'unid', lowStock: 20 },
  { id: 'abacaxi', name: 'Abacaxi', stock: 50, unit: 'unid', lowStock: 5 },
  { id: 'leite-condensado', name: 'Leite Condensado', stock: 40, unit: 'latas', lowStock: 5 },
  { id: 'vinho', name: 'Vinho Tinto', stock: 30, unit: 'garrafas', lowStock: 4 },
  { id: 'whisky-old', name: 'Whisky Old Star', stock: 20, unit: 'garrafas', lowStock: 3 },
  { id: 'whisky-red', name: 'Whisky Red Label', stock: 15, unit: 'garrafas', lowStock: 2 },
  { id: 'gelo', name: 'Gelo', stock: 50, unit: 'kg', lowStock: 10 },
];

import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Toaster } from '@/components/ui/toaster';
import CustomerApp from '@/components/CustomerApp';
import AdminApp from '@/components/AdminApp';
import { Button } from '@/components/ui/button';
import { Users, Settings } from 'lucide-react';
import { initialInventory } from '@/data/inventoryData';
import { kioskData } from '@/data/kioskData';

function App() {
  const [currentView, setCurrentView] = useState('customer');

  useEffect(() => {
    // Inicializa o inventário e a localização do bar no localStorage se não existirem
    if (!localStorage.getItem('inventory')) {
      localStorage.setItem('inventory', JSON.stringify(initialInventory));
    }
    if (!localStorage.getItem('barLocation')) {
      localStorage.setItem('barLocation', JSON.stringify({ kiosk: kioskData[0], reference: 'Perto do palco principal' }));
    }
  }, []);

  return (
    <>
      <Helmet>
        <title>Super Drinks - Sistema de Pedidos Digital</title>
        <meta name="description" content="Sistema de pedidos digital para o Super Drinks. Faça seu pedido direto da mesa!" />
      </Helmet>
      
      <div className="min-h-screen bg-gradient-to-br from-yellow-400 via-orange-500 to-red-500">
        {/* Header com navegação */}
        <header className="bg-white/10 backdrop-blur-md border-b border-white/20 sticky top-0 z-50">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <motion.div 
                className="flex items-center space-x-3"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
              >
                <img src="https://storage.googleapis.com/hostinger-horizons-assets-prod/f7679c3c-ea19-4e9c-9de2-a32884b38851/fff944bfd3318cd539e7b9165d080dee.png" alt="Super Drinks Logo" className="w-12 h-12" />
                <div>
                  <h1 className="text-2xl font-bold text-white text-outline">Super Drinks</h1>
                  <p className="text-white/80 text-sm text-outline">Praia Grande</p>
                </div>
              </motion.div>

              <div className="flex space-x-2">
                <Button
                  variant={currentView === 'customer' ? 'default' : 'outline'}
                  onClick={() => setCurrentView('customer')}
                  className={`${currentView === 'customer' 
                    ? 'bg-white text-orange-600 hover:bg-white/90' 
                    : 'border-white text-white hover:bg-white/10 text-outline'
                  }`}
                >
                  <Users className="w-4 h-4 mr-2" />
                  Cliente
                </Button>
                <Button
                  variant={currentView === 'admin' ? 'default' : 'outline'}
                  onClick={() => setCurrentView('admin')}
                  className={`${currentView === 'admin' 
                    ? 'bg-white text-orange-600 hover:bg-white/90' 
                    : 'border-white text-white hover:bg-white/10 text-outline'
                  }`}
                >
                  <Settings className="w-4 h-4 mr-2" />
                  Balcão
                </Button>
              </div>
            </div>
          </div>
        </header>

        {/* Conteúdo principal */}
        <main className="container mx-auto px-4 py-6">
          {currentView === 'customer' ? <CustomerApp /> : <AdminApp />}
        </main>

        <Toaster />
      </div>
    </>
  );
}

export default App;
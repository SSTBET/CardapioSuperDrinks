import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { MapPin, ChefHat, Bike, CheckCircle } from 'lucide-react';

export default function OrderTracking({ order, barLocation, onNewOrder }) {
  const [currentStatus, setCurrentStatus] = useState(order.status);

  useEffect(() => {
    const interval = setInterval(() => {
      const allOrders = JSON.parse(localStorage.getItem('orders') || '[]');
      const updatedOrder = allOrders.find(o => o.id === order.id);
      if (updatedOrder) {
        setCurrentStatus(updatedOrder.status);
      }
    }, 2000);
    return () => clearInterval(interval);
  }, [order.id]);

  const statusConfig = {
    pending: { text: 'Pedido Recebido', icon: <CheckCircle />, progress: 10, time: '2 min' },
    preparing: { text: 'Em Preparo', icon: <ChefHat />, progress: 40, time: '5 min' },
    ready: { text: 'Pronto para Entrega', icon: <Bike />, progress: 75, time: '8 min' },
    delivered: { text: 'Entregue!', icon: <CheckCircle />, progress: 100, time: 'Concluído' },
  };

  const currentConfig = statusConfig[currentStatus] || statusConfig.pending;

  return (
    <motion.div
      className="max-w-md mx-auto bg-white/10 backdrop-blur-md rounded-2xl p-8 border border-white/20"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-white text-outline mb-2">Seu pedido está a caminho!</h2>
        <p className="text-white/80 text-outline">Acompanhe o status em tempo real.</p>
      </div>

      <div className="space-y-6">
        {/* Barra de Progresso */}
        <div>
          <div className="relative h-4 bg-white/20 rounded-full overflow-hidden">
            <motion.div
              className="absolute top-0 left-0 h-full bg-gradient-to-r from-green-400 to-blue-500 rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${currentConfig.progress}%` }}
              transition={{ duration: 0.5, ease: "easeInOut" }}
            />
          </div>
          <div className="flex justify-between text-xs text-white text-outline mt-2">
            <span>Recebido</span>
            <span>Preparando</span>
            <span>A Caminho</span>
            <span>Entregue</span>
          </div>
        </div>

        {/* Status Atual */}
        <div className="text-center bg-white/10 rounded-lg p-4">
          <div className="flex items-center justify-center text-white text-2xl mb-2">
            <span className="mr-3">{currentConfig.icon}</span>
            <span className="font-bold text-outline">{currentConfig.text}</span>
          </div>
          <p className="text-white/80 text-outline">Tempo estimado: {currentConfig.time}</p>
        </div>

        {/* Localização do Bar */}
        <div className="text-center bg-white/10 rounded-lg p-4">
          <div className="flex items-center justify-center text-white text-xl mb-2">
            <MapPin className="w-5 h-5 mr-2" />
            <span className="font-bold text-outline">Localização do Bar</span>
          </div>
          <p className="text-white/80 text-outline">
            {barLocation?.kiosk || 'N/A'} - {barLocation?.reference || 'Buscando...'}
          </p>
        </div>
      </div>

      <Button onClick={onNewOrder} className="w-full mt-8 bg-white text-orange-600 hover:bg-white/90">
        Fazer Novo Pedido
      </Button>
    </motion.div>
  );
}
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { User } from 'lucide-react';
import { kioskData } from '@/data/kioskData';

export default function CustomerInfoForm({ onSubmit }) {
  const [name, setName] = useState('');
  const [kiosk, setKiosk] = useState('');
  const [reference, setReference] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (name && kiosk) {
      onSubmit({ name, kiosk, reference });
    }
  };

  return (
    <motion.div 
      className="max-w-md mx-auto"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <form onSubmit={handleSubmit} className="bg-white/10 backdrop-blur-md rounded-2xl p-8 border border-white/20">
        <div className="text-center mb-8">
          <User className="w-16 h-16 text-white mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white text-outline mb-2">Identifique-se</h2>
          <p className="text-white/80 text-outline">Precisamos de algumas informações para entregar seu pedido.</p>
        </div>

        <div className="space-y-4">
          <div>
            <Label htmlFor="name" className="text-white text-outline">Seu Nome</Label>
            <Input id="name" name="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Ex: João Silva" required className="bg-white/20 border-white/30 text-white placeholder:text-white/60" />
          </div>
          <div>
            <Label htmlFor="kiosk" className="text-white text-outline">Quiosque / Trailer</Label>
            <Select onValueChange={setKiosk} value={kiosk}>
                <SelectTrigger id="kiosk" className="bg-white/20 border-white/30 text-white">
                    <SelectValue placeholder="Selecione o quiosque" />
                </SelectTrigger>
                <SelectContent>
                    {kioskData.map(kioskName => (
                        <SelectItem key={kioskName} value={kioskName}>{kioskName}</SelectItem>
                    ))}
                </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="reference" className="text-white text-outline">Ponto de Referência (opcional)</Label>
            <Input id="reference" name="reference" value={reference} onChange={(e) => setReference(e.target.value)} placeholder="Ex: Guarda-sol azul" className="bg-white/20 border-white/30 text-white placeholder:text-white/60" />
          </div>
        </div>

        <Button type="submit" className="w-full mt-8 bg-white text-orange-600 hover:bg-white/90">
          Começar a Pedir
        </Button>
      </form>
    </motion.div>
  );
}
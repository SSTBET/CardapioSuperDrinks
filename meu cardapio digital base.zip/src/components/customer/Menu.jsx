import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';
import { menuData } from '@/data/menuData';

export default function Menu({ onAddToCart }) {
  const [selectedCategory, setSelectedCategory] = useState('caipirinhas');

  return (
    <>
      {/* Categorias */}
      <motion.div 
        className="mb-6"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
      >
        <div className="flex space-x-2 overflow-x-auto pb-2">
          {Object.keys(menuData).map(category => (
            <Button
              key={category}
              onClick={() => setSelectedCategory(category)}
              variant={selectedCategory === category ? 'default' : 'outline'}
              className={`whitespace-nowrap ${selectedCategory === category 
                ? 'bg-white text-orange-600 hover:bg-white/90' 
                : 'border-white text-white hover:bg-white/10 text-outline'
              }`}
            >
              {menuData[category].title}
            </Button>
          ))}
        </div>
      </motion.div>

      {/* Menu Items */}
      <motion.div 
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
      >
        {menuData[selectedCategory].items.map(item => (
          <motion.div
            key={item.id}
            className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 hover:bg-white/20 transition-all duration-300"
            whileHover={{ scale: 1.02 }}
            layout
          >
            <h3 className="text-xl font-bold text-white text-outline mb-2">{item.name}</h3>
            <p className="text-white/80 text-sm mb-4 text-outline">{item.description}</p>
            
            <div className="space-y-3">
              {item.sizes.map(size => (
                <div key={size.size} className="flex items-center justify-between">
                  <div>
                    <span className="text-white font-medium text-outline">{size.size}</span>
                    <span className="text-white/80 ml-2 text-outline">R$ {size.price.toFixed(2)}</span>
                  </div>
                  <Button
                    onClick={() => onAddToCart(item, size.size, size.price)}
                    size="sm"
                    className="bg-white/20 hover:bg-white/30 text-white"
                  >
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
          </motion.div>
        ))}
      </motion.div>
    </>
  );
}
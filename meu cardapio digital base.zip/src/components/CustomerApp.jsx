import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { toast } from '@/components/ui/use-toast';
import { kioskData } from '@/data/kioskData';
import CustomerInfoForm from '@/components/customer/CustomerInfoForm';
import OrderTracking from '@/components/customer/OrderTracking';
import Menu from '@/components/customer/Menu';
import Cart from '@/components/customer/Cart';
import { Button } from '@/components/ui/button';
import { ShoppingCart, MapPin } from 'lucide-react';

export default function CustomerApp() {
  const [customerInfo, setCustomerInfo] = useState(null);
  const [cart, setCart] = useState([]);
  const [showCart, setShowCart] = useState(false);
  const [submittedOrder, setSubmittedOrder] = useState(null);
  const [barLocation, setBarLocation] = useState(null);

  useEffect(() => {
    const savedInfo = localStorage.getItem('customerInfo');
    if (savedInfo) {
      setCustomerInfo(JSON.parse(savedInfo));
    }
    
    const savedOrderId = sessionStorage.getItem('lastOrderId');
    if (savedOrderId) {
        const allOrders = JSON.parse(localStorage.getItem('orders') || '[]');
        const lastOrder = allOrders.find(o => o.id === parseInt(savedOrderId));
        if (lastOrder && lastOrder.status !== 'delivered') {
            setSubmittedOrder(lastOrder);
        }
    }

    const fetchBarLocation = () => {
        const location = JSON.parse(localStorage.getItem('barLocation') || 'null');
        setBarLocation(location);
    };
    fetchBarLocation();
    const interval = setInterval(fetchBarLocation, 3000);
    return () => clearInterval(interval);

  }, []);

  const handleInfoSubmit = (info) => {
    setCustomerInfo(info);
    localStorage.setItem('customerInfo', JSON.stringify(info));
    toast({
      title: "Informações salvas! ✅",
      description: `Olá ${info.name}, bem-vindo(a) ao ${info.kiosk}!`,
    });
  };

  const addToCart = (item, size, price) => {
    const cartItem = {
      id: `${item.id}-${size}`,
      name: item.name,
      size,
      price,
      quantity: 1,
      description: item.description
    };

    setCart(prevCart => {
      const existingItem = prevCart.find(cartItem => cartItem.id === `${item.id}-${size}`);
      if (existingItem) {
        return prevCart.map(cartItem =>
          cartItem.id === `${item.id}-${size}`
            ? { ...cartItem, quantity: cartItem.quantity + 1 }
            : cartItem
        );
      }
      return [...prevCart, cartItem];
    });

    toast({
      title: "Adicionado ao carrinho! 🍹",
      description: <span className="text-outline">{`${item.name} (${size}) - R$ ${price.toFixed(2)}`}</span>,
    });
  };

  const submitOrder = () => {
    if (cart.length === 0) {
      toast({
        title: "Carrinho vazio! 🛒",
        description: "Adicione itens ao carrinho antes de fazer o pedido.",
        variant: "destructive"
      });
      return;
    }

    const order = {
      id: Date.now(),
      customerName: customerInfo.name,
      location: {
        kiosk: customerInfo.kiosk,
        reference: customerInfo.reference,
      },
      items: cart,
      total: cart.reduce((total, item) => total + (item.price * item.quantity), 0),
      status: 'pending',
      timestamp: new Date().toISOString()
    };

    const existingOrders = JSON.parse(localStorage.getItem('orders') || '[]');
    localStorage.setItem('orders', JSON.stringify([...existingOrders, order]));
    
    setSubmittedOrder(order);
    sessionStorage.setItem('lastOrderId', order.id);

    setCart([]);
    setShowCart(false);

    toast({
      title: "Pedido enviado! 🚀",
      description: `Seu pedido para o ${customerInfo.kiosk} foi enviado para o balcão!`,
    });
  };

  const handleNewOrder = () => {
    setSubmittedOrder(null);
    sessionStorage.removeItem('lastOrderId');
  };

  if (submittedOrder) {
    return <OrderTracking order={submittedOrder} barLocation={barLocation} onNewOrder={handleNewOrder} />;
  }

  if (!customerInfo) {
    return <CustomerInfoForm onSubmit={handleInfoSubmit} />;
  }

  return (
    <div className="max-w-6xl mx-auto">
      {/* Header do cliente */}
      <motion.div 
        className="bg-white/10 backdrop-blur-md rounded-2xl p-6 mb-6 border border-white/20"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="bg-white/20 rounded-full p-3">
              <MapPin className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white text-outline">Olá, {customerInfo.name}!</h2>
              <p className="text-white/80 text-outline">{customerInfo.kiosk} - {customerInfo.reference}</p>
            </div>
          </div>

          <Button
            onClick={() => setShowCart(true)}
            className="bg-white/20 hover:bg-white/30 text-white border border-white/30 relative text-outline"
            variant="outline"
          >
            <ShoppingCart className="w-5 h-5 mr-2" />
            Carrinho
            {cart.length > 0 && (
              <span className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold text-outline">
                {cart.reduce((total, item) => total + item.quantity, 0)}
              </span>
            )}
          </Button>
        </div>
      </motion.div>

      <Menu onAddToCart={addToCart} />

      <Cart 
        showCart={showCart}
        setShowCart={setShowCart}
        cart={cart}
        setCart={setCart}
        submitOrder={submitOrder}
      />
    </div>
  );
}
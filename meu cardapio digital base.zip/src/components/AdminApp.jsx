import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { initialInventory } from '@/data/inventoryData';
import { kioskData } from '@/data/kioskData';
import InventoryManager from '@/components/admin/InventoryManager';
import BarLocationManager from '@/components/admin/BarLocationManager';
import DashboardStats from '@/components/admin/DashboardStats';
import OrderList from '@/components/admin/OrderList';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

export default function AdminApp() {
  const [orders, setOrders] = useState([]);
  const [filter, setFilter] = useState('all');
  const [inventory, setInventory] = useState([]);
  const [barLocation, setBarLocation] = useState({ kiosk: kioskData[0], reference: '' });

  useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 2000);
    return () => clearInterval(interval);
  }, []);

  const loadData = () => {
    const savedOrders = JSON.parse(localStorage.getItem('orders') || '[]');
    const savedInventory = JSON.parse(localStorage.getItem('inventory') || JSON.stringify(initialInventory));
    const savedLocation = JSON.parse(localStorage.getItem('barLocation') || JSON.stringify({ kiosk: kioskData[0], reference: 'Perto do palco principal' }));
    
    setOrders(savedOrders.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp)));
    setInventory(savedInventory);
    setBarLocation(savedLocation);
  };

  const deductInventory = (items) => {
    let tempInventory = JSON.parse(localStorage.getItem('inventory') || '[]');
    
    items.forEach(orderItem => {
      const ingredientName = orderItem.name.split(' ')[0].toLowerCase();
      const inventoryItem = tempInventory.find(inv => inv.name.toLowerCase().includes(ingredientName));
      
      if (inventoryItem) {
        inventoryItem.stock -= orderItem.quantity;
      }
    });

    setInventory(tempInventory);
    localStorage.setItem('inventory', JSON.stringify(tempInventory));
  };

  const updateOrderStatus = (orderId, newStatus) => {
    let orderToUpdate;
    const updatedOrders = orders.map(order => {
      if (order.id === orderId) {
        orderToUpdate = { ...order, status: newStatus };
        return orderToUpdate;
      }
      return order;
    });
    
    setOrders(updatedOrders);
    localStorage.setItem('orders', JSON.stringify(updatedOrders));

    if (newStatus === 'preparing' && orderToUpdate) {
      deductInventory(orderToUpdate.items);
    }

    const statusMessages = {
      preparing: 'Pedido em preparo! 👨‍🍳',
      ready: 'Pedido pronto! ✅',
      delivered: 'Pedido entregue! 🎉'
    };

    toast({
      title: statusMessages[newStatus],
      description: `Pedido #${orderId} atualizado`,
    });
  };

  const filteredOrders = orders.filter(order => {
    if (filter === 'all') return true;
    return order.status === filter;
  });

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
      {/* Coluna de Pedidos */}
      <div className="lg:col-span-2">
        <DashboardStats orders={orders} />

        {/* Filtros */}
        <motion.div 
          className="mb-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          <div className="flex space-x-2 overflow-x-auto pb-2">
            {[
              { key: 'all', label: 'Todos' },
              { key: 'pending', label: 'Pendentes' },
              { key: 'preparing', label: 'Preparando' },
              { key: 'ready', label: 'Prontos' },
              { key: 'delivered', label: 'Entregues' }
            ].map(filterOption => (
              <Button
                key={filterOption.key}
                onClick={() => setFilter(filterOption.key)}
                variant={filter === filterOption.key ? 'default' : 'outline'}
                className={`whitespace-nowrap ${filter === filterOption.key 
                  ? 'bg-white text-orange-600 hover:bg-white/90' 
                  : 'border-white text-white hover:bg-white/10 text-outline'
                }`}
              >
                {filterOption.label}
              </Button>
            ))}
          </div>
        </motion.div>

        <OrderList orders={filteredOrders} updateOrderStatus={updateOrderStatus} />
      </div>

      {/* Coluna de Gerenciamento */}
      <div className="space-y-8">
        <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.4 }}>
            <InventoryManager inventory={inventory} setInventory={setInventory} />
        </motion.div>
        <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.5 }}>
            <BarLocationManager barLocation={barLocation} setBarLocation={setBarLocation} />
        </motion.div>
      </div>
    </div>
  );
}
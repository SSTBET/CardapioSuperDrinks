import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { User, RefreshCw, MapPin, CheckCircle } from 'lucide-react';

export default function OrderList({ orders, updateOrderStatus }) {
  const getStatusColor = (status) => {
    const colors = {
      pending: 'bg-yellow-500',
      preparing: 'bg-blue-500',
      ready: 'bg-green-500',
      delivered: 'bg-gray-500'
    };
    return colors[status] || 'bg-gray-500';
  };

  const getStatusText = (status) => {
    const texts = {
      pending: 'Pendente',
      preparing: 'Preparando',
      ready: 'Pronto',
      delivered: 'Entregue'
    };
    return texts[status] || 'Desconhecido';
  };

  return (
    <motion.div 
      className="space-y-4"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.3 }}
    >
      {orders.length === 0 ? (
        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 border border-white/20 text-center">
          <p className="text-white/80 text-lg text-outline">Nenhum pedido encontrado</p>
        </div>
      ) : (
        orders.map(order => (
          <motion.div
            key={order.id}
            className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            layout
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center space-x-4">
                <div className="bg-white/20 rounded-full p-3">
                  <User className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white text-outline">{order.customerName || `Pedido #${order.id}`}</h3>
                  <p className="text-white/80 text-outline">
                    <MapPin className="inline w-4 h-4 mr-1" />
                    {order.location ? `${order.location.kiosk} - ${order.location.reference}` : `Mesa ${order.table || 'N/A'}`}
                  </p>
                  <p className="text-white/60 text-sm text-outline">
                    {new Date(order.timestamp).toLocaleString('pt-BR')}
                  </p>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <span className={`px-3 py-1 rounded-full text-white text-sm font-medium text-outline ${getStatusColor(order.status)}`}>
                  {getStatusText(order.status)}
                </span>
                <span className="text-2xl font-bold text-white text-outline">R$ {order.total.toFixed(2)}</span>
              </div>
            </div>

            <div className="bg-white/5 rounded-lg p-4 mb-4">
              <h4 className="text-white font-medium mb-3 text-outline">Itens do Pedido:</h4>
              <div className="space-y-2">
                {order.items.map((item, index) => (
                  <div key={index} className="flex justify-between items-center text-white/80 text-outline">
                    <span>{item.quantity}x {item.name} ({item.size})</span>
                    <span>R$ {(item.price * item.quantity).toFixed(2)}</span>
                  </div>
                ))}
              </div>
            </div>

            {order.status !== 'delivered' && (
              <div className="flex space-x-2">
                {order.status === 'pending' && (
                  <Button onClick={() => updateOrderStatus(order.id, 'preparing')} className="bg-blue-600 hover:bg-blue-700 text-white">
                    <RefreshCw className="w-4 h-4 mr-2" /> Iniciar Preparo
                  </Button>
                )}
                {order.status === 'preparing' && (
                  <Button onClick={() => updateOrderStatus(order.id, 'ready')} className="bg-green-600 hover:bg-green-700 text-white">
                    <CheckCircle className="w-4 h-4 mr-2" /> Marcar como Pronto
                  </Button>
                )}
                {order.status === 'ready' && (
                  <Button onClick={() => updateOrderStatus(order.id, 'delivered')} className="bg-gray-600 hover:bg-gray-700 text-white">
                    <CheckCircle className="w-4 h-4 mr-2" /> Marcar como Entregue
                  </Button>
                )}
              </div>
            )}
          </motion.div>
        ))
      )}
    </motion.div>
  );
}
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { MapPin } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { kioskData } from '@/data/kioskData';

export default function BarLocationManager({ barLocation, setBarLocation }) {
    const [location, setLocation] = useState(barLocation);

    const handleSaveLocation = (e) => {
        e.preventDefault();
        setBarLocation(location);
        localStorage.setItem('barLocation', JSON.stringify(location));
        toast({ title: "Localização atualizada!", description: `O bar agora está em ${location.kiosk}.` });
    };

    return (
        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
            <h3 className="text-2xl font-bold text-white text-outline mb-4 flex items-center">
                <MapPin className="w-6 h-6 mr-3" />
                Localização do Bar
            </h3>
            <form onSubmit={handleSaveLocation} className="space-y-4">
                <div>
                    <Label htmlFor="bar-kiosk" className="text-white text-outline">Quiosque Atual</Label>
                    <Select
                        value={location.kiosk}
                        onValueChange={(value) => setLocation(prev => ({ ...prev, kiosk: value }))}
                    >
                        <SelectTrigger id="bar-kiosk" className="bg-white/20 border-white/30 text-white">
                            <SelectValue placeholder="Selecione o quiosque" />
                        </SelectTrigger>
                        <SelectContent>
                            {kioskData.map(kioskName => (
                                <SelectItem key={kioskName} value={kioskName}>{kioskName}</SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>
                <div>
                    <Label htmlFor="bar-ref" className="text-white text-outline">Ponto de Referência</Label>
                    <Input 
                        id="bar-ref"
                        type="text"
                        value={location.reference}
                        onChange={(e) => setLocation(prev => ({ ...prev, reference: e.target.value }))}
                        className="bg-white/20 border-white/30 text-white"
                    />
                </div>
                <Button type="submit" className="w-full bg-white text-orange-600 hover:bg-white/90">
                    Atualizar Localização
                </Button>
            </form>
        </div>
    );
}
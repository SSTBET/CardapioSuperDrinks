import React from 'react';
import { motion } from 'framer-motion';
import { Clock, CheckCircle, DollarSign } from 'lucide-react';

export default function DashboardStats({ orders }) {
  const getTotalRevenue = () => {
    return orders
      .filter(order => order.status === 'delivered')
      .reduce((total, order) => total + order.total, 0);
  };

  const getPendingCount = () => {
    return orders.filter(order => order.status === 'pending').length;
  };

  const stats = [
    {
      label: 'Pedidos Pendentes',
      value: getPendingCount(),
      icon: Clock,
      color: 'yellow'
    },
    {
      label: 'Total de Pedidos',
      value: orders.length,
      icon: CheckCircle,
      color: 'green'
    },
    {
      label: 'Faturamento',
      value: `R$ ${getTotalRevenue().toFixed(2)}`,
      icon: DollarSign,
      color: 'blue'
    }
  ];

  return (
    <motion.div 
      className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8"
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
    >
      {stats.map((stat, index) => (
        <div key={index} className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
          <div className="flex items-center space-x-4">
            <div className={`bg-${stat.color}-500/20 rounded-full p-3`}>
              <stat.icon className={`w-6 h-6 text-${stat.color}-300`} />
            </div>
            <div>
              <h3 className="text-2xl font-bold text-white text-outline">{stat.value}</h3>
              <p className="text-white/80 text-outline">{stat.label}</p>
            </div>
          </div>
        </div>
      ))}
    </motion.div>
  );
}
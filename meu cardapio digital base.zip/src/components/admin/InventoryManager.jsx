import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { Package, Edit } from 'lucide-react';
import { Input } from '@/components/ui/input';

export default function InventoryManager({ inventory, setInventory }) {
  const [editingItem, setEditingItem] = useState(null);
  const [editValue, setEditValue] = useState(0);

  const handleEdit = (item) => {
    setEditingItem(item.id);
    setEditValue(item.stock);
  };

  const handleSave = (itemId) => {
    const newInventory = inventory.map(item => 
      item.id === itemId ? { ...item, stock: parseInt(editValue, 10) || 0 } : item
    );
    setInventory(newInventory);
    localStorage.setItem('inventory', JSON.stringify(newInventory));
    setEditingItem(null);
    toast({ title: "Estoque atualizado!", description: `${newInventory.find(i => i.id === itemId).name} agora tem ${editValue} em estoque.` });
  };

  const getStockColor = (stock, lowThreshold) => {
    if (stock <= lowThreshold) return 'text-red-400';
    if (stock <= lowThreshold * 2) return 'text-yellow-400';
    return 'text-green-400';
  };

  return (
    <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
      <h3 className="text-2xl font-bold text-white text-outline mb-4 flex items-center">
        <Package className="w-6 h-6 mr-3" />
        Controle de Estoque
      </h3>
      <div className="space-y-3 max-h-96 overflow-y-auto pr-2">
        {inventory.map(item => (
          <div key={item.id} className="flex items-center justify-between bg-white/5 p-3 rounded-lg">
            <div>
              <p className="text-white font-medium text-outline">{item.name}</p>
              <p className={`text-sm font-bold text-outline ${getStockColor(item.stock, item.lowStock)}`}>
                Estoque: {item.stock} {item.unit}
              </p>
            </div>
            {editingItem === item.id ? (
              <div className="flex items-center space-x-2">
                <Input 
                  type="number" 
                  value={editValue} 
                  onChange={(e) => setEditValue(e.target.value)}
                  className="w-24 bg-white/20 border-white/30 text-white"
                />
                <Button size="sm" onClick={() => handleSave(item.id)}>Salvar</Button>
              </div>
            ) : (
              <Button size="sm" variant="ghost" onClick={() => handleEdit(item)}>
                <Edit className="w-4 h-4 text-white" />
              </Button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}